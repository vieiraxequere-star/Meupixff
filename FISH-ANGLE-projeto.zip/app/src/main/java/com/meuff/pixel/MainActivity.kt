package com.meuff.pixel

import android.app.Activity
import android.graphics.Color
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import rikka.shizuku.Shizuku
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val BG = Color.parseColor("#100B1E")
    private val PANEL = Color.parseColor("#21122F")
    private val LINE = Color.parseColor("#49305F")
    private val VIOLET = Color.parseColor("#B589FF")
    private val YELLOW = Color.parseColor("#FFE06A")
    private val MUTED = Color.parseColor("#C4ADC9")

    private val games = listOf("Free Fire" to "com.dts.freefireth", "Free Fire MAX" to "com.dts.freefiremax")
    // Estilo = nível de LOD de textura do ANGLE (0 = original, 1..4 = mais blocos)
    private val presets = listOf("Natural", "Brisa", "Arcade", "Voxel", "Máximo")

    private var pkg = games[0].second
    private var blocks = true   // Textura em blocos (ANGLE)
    private var leve = true     // Modo Leve (reduz resolução)
    private var level = 3        // 0..4
    private var sharp = true     // Pixels definidos (filtro nearest)
    private var steps = true     // Distância em etapas (mip nearest)
    private var forceWm = true   // Reduz a resolução da tela inteira (wm size)
    private var perf = true      // Modo desempenho fixo
    private var noAnim = true    // Desliga animações do sistema
    private var ram = true       // Limpa RAM ao aplicar
    private var cpu = false      // CPU em desempenho (root)
    private val prefs by lazy { getSharedPreferences("fa", Context.MODE_PRIVATE) }

    private lateinit var status: TextView
    private lateinit var scaleLabel: TextView
    private lateinit var log: TextView
    private lateinit var seek: SeekBar        // resolução (Modo Leve)
    private lateinit var lvSeek: SeekBar      // intensidade dos blocos 0..4
    private lateinit var lvLabel: TextView
    private val presetBtns = mutableListOf<TextView>()
    private val gameBtns = mutableListOf<TextView>()

    private val onBinder = Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }
    private val onDead = Shizuku.OnBinderDeadListener { runOnUiThread { refresh() } }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun scale() = 0.30 + seek.progress / 100.0
    private val F = "debug.angle.feature_overrides_enabled"

    private fun box(fill: Int, stroke: Int, r: Int = 14) = GradientDrawable().apply {
        setColor(fill); setStroke(dp(1), stroke); cornerRadius = dp(r).toFloat()
    }

    private fun tv(t: String, size: Float = 14f, color: Int = Color.WHITE) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
    }

    private fun card(vararg v: android.view.View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = box(PANEL, LINE)
        setPadding(dp(16), dp(14), dp(16), dp(14))
        v.forEach { addView(it) }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
    }

    private fun toggleRow(title: String, sub: String, init: Boolean, on: (Boolean) -> Unit): LinearLayout {
        val txt = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv(title, 16f)); addView(tv(sub, 12f, MUTED))
        }
        val sw = Switch(this).apply { isChecked = init; setOnCheckedChangeListener { _, c -> on(c) } }
        return LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(txt, LinearLayout.LayoutParams(0, -2, 1f))
            addView(sw)
        }
    }

    private fun pill(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        setPadding(dp(4), dp(14), dp(4), dp(14))
        setOnClickListener { onClick() }
    }

    private fun bigBtn(t: String, primary: Boolean, f: () -> Unit) = TextView(this).apply {
        text = t; textSize = 15f; gravity = Gravity.CENTER
        setTextColor(if (primary) Color.parseColor("#1A1320") else Color.WHITE)
        background = if (primary) box(YELLOW, YELLOW, 16) else box(Color.TRANSPARENT, LINE, 16)
        setPadding(dp(8), dp(16), dp(8), dp(16))
        setOnClickListener { f() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(28))
            setBackgroundColor(BG)
        }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(ImageView(this).apply {
            setImageResource(R.drawable.logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, LinearLayout.LayoutParams(dp(56), dp(56)))
        head.addView(tv("FISH ANGLE", 26f).apply { setPadding(dp(12), 0, 0, 0) })
        root.addView(head)
        status = tv("", 13f, MUTED); root.addView(status)
        root.addView(bigBtn("Conectar (depuração por Wi-Fi)", false) { connect() })

        // Jogo
        val gRow = LinearLayout(this)
        games.forEachIndexed { i, (n, p) ->
            val b = pill(n) { pkg = p; paintGames() }
            gameBtns.add(b)
            gRow.addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { if (i > 0) leftMargin = dp(8) })
        }
        root.addView(card(tv("JOGO", 11f, VIOLET), gRow))

        // Textura em blocos
        val pRow = LinearLayout(this)
        presets.forEachIndexed { i, n ->
            val b = pill(n) { level = i; lvSeek.progress = i; paintPresets(); upLabel() }
            presetBtns.add(b)
            pRow.addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { if (i > 0) leftMargin = dp(6) })
        }
        lvLabel = tv("", 14f)
        lvSeek = SeekBar(this).apply {
            max = 4; progress = level
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { level = p; paintPresets(); upLabel() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        val ends = LinearLayout(this).apply {
            addView(tv("Mais detalhe", 11f, MUTED), LinearLayout.LayoutParams(0, -2, 1f))
            addView(tv("Mais blocos", 11f, MUTED))
        }
        root.addView(card(
            toggleRow("Textura em blocos", "Muda a amostragem de texturas (ANGLE).", true) { blocks = it },
            tv("ENCONTRE O SEU ESTILO", 11f, VIOLET).apply { setPadding(0, dp(14), 0, dp(6)) },
            pRow, lvLabel, lvSeek, ends,
            toggleRow("Pixels definidos", "Bordas marcadas, visual pixelado.", true) { sharp = it }
                .apply { setPadding(0, dp(14), 0, 0) },
            toggleRow("Distância em etapas", "Detalhe muda em degraus ao olhar longe.", true) { steps = it }
                .apply { setPadding(0, dp(14), 0, 0) }
        ))

        // Modo Leve
        scaleLabel = tv("", 14f)
        seek = SeekBar(this).apply {
            max = 70; progress = 40 // 0.70
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { upLabel() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(card(
            toggleRow("Modo Leve", "Reduz a resolução de renderização.", true) { leve = it },
            scaleLabel, seek,
            toggleRow("Forçar resolução da tela", "Use se o Modo Leve não pegar (ex.: Samsung A05s). Reduz a tela toda; Restaurar volta ao normal.", true) { forceWm = it }
                .apply { setPadding(0, dp(14), 0, 0) }
        ))

        root.addView(card(
            tv("EXTRAS DE DESEMPENHO", 11f, VIOLET),
            toggleRow("Modo desempenho fixo", "Evita o sistema baixar o desempenho aos poucos.", true) { perf = it }
                .apply { setPadding(0, dp(10), 0, 0) },
            toggleRow("Desligar animações", "Menos trabalho para a GPU fora do jogo.", true) { noAnim = it }
                .apply { setPadding(0, dp(14), 0, 0) },
            toggleRow("Limpar RAM ao aplicar", "Fecha apps em segundo plano antes de abrir o jogo.", true) { ram = it }
                .apply { setPadding(0, dp(14), 0, 0) },
            toggleRow("CPU em desempenho (root)", "Trava a CPU no modo desempenho. Esquenta e gasta mais bateria.", false) { cpu = it }
                .apply { setPadding(0, dp(14), 0, 0) }
        ))

        root.addView(tv("Depois de aplicar, o jogo é reaberto. O ANGLE pode afetar outros apps; use Restaurar para voltar ao padrão.", 12f, MUTED).apply { setPadding(0, dp(14), 0, 0) })
        root.addView(bigBtn("Aplicar perfil e reabrir jogo", true) { apply() })
        root.addView(bigBtn("Ver configuração / ANGLE", false) { show() })
        root.addView(bigBtn("Restaurar padrão", false) { restore() })
        log = tv("", 12f, MUTED).apply { setPadding(0, dp(14), 0, 0) }
        root.addView(log)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG); layoutParams = ViewGroup.LayoutParams(-1, -1); addView(root)
        })
        paintGames(); paintPresets(); upLabel()
        thread { Sh.rootReady(); runOnUiThread { refresh() } }
        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPerm)
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeBinderReceivedListener(onBinder)
        Shizuku.removeBinderDeadListener(onDead)
        Shizuku.removeRequestPermissionResultListener(onPerm)
    }

    private fun paintGames() = gameBtns.forEachIndexed { i, b ->
        b.background = if (games[i].second == pkg) box(Color.parseColor("#352045"), YELLOW) else box(BG, LINE)
    }

    private fun paintPresets() = presetBtns.forEachIndexed { i, b ->
        b.background = if (i == level) box(Color.parseColor("#352045"), YELLOW) else box(BG, LINE)
    }

    private fun upLabel() {
        scaleLabel.text = "Resolução: %d%%".format((scale() * 100).toInt())
        lvLabel.text = "Intensidade dos blocos: %02d / 04".format(level)
    }

    private fun refresh() {
        status.text = when {
            Sh.rootOk == true || Sh.shizukuReady() -> "Depuração por Wi-Fi: conectada"
            Sh.shizukuRunning() -> "Depuração por Wi-Fi: falta autorizar o app"
            else -> "Depuração por Wi-Fi: desconectada. Toque em Conectar."
        }
    }

    private fun connect() {
        thread {
            val root = Sh.rootReady(true)
            runOnUiThread {
                if (!root) try {
                    if (Sh.shizukuRunning() && !Sh.shizukuReady()) Shizuku.requestPermission(1)
                } catch (_: Throwable) {}
                refresh()
            }
            val w = Sh.who()
            runOnUiThread { refresh(); out(if (w.isEmpty()) "Sem acesso. Conceda a permissão ou inicie o serviço." else "Depuração por Wi-Fi conectada.") }
        }
    }

    private fun out(s: String) { log.text = s }

    private fun task(f: () -> String) = thread {
        val r = try { f() } catch (e: Throwable) { "Erro: ${e.message}" }
        runOnUiThread { out(r) }
    }

    private fun looksFailed(s: String) = Regex("(?i)error|exception|unknown|usage|invalid|denied").containsMatchIn(s)

    private fun features(): String {
        val l = mutableListOf<String>()
        if (level > 0) l.add("forceTextureLodOffset$level")
        if (sharp) l.add("forceNearestFiltering")
        if (steps) l.add("forceNearestMipFiltering")
        return l.joinToString(":")
    }

    private fun physSize(): Pair<Int, Int>? {
        val m = Regex("Physical size: (\\d+)x(\\d+)").find(Sh.run("wm size")) ?: return null
        return m.groupValues[1].toInt() to m.groupValues[2].toInt()
    }

    private fun govLines(): List<String> =
        Sh.run("for f in /sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_governor; do echo \"\$f \$(cat \$f)\"; done")
            .lines().filter { it.startsWith("/sys") }

    private fun cpuOn(): String {
        if (Sh.rootOk != true) return "CPU em desempenho precisa de root."
        val cur = govLines()
        if (cur.isEmpty()) return "CPU: este aparelho não expõe o controle."
        if (prefs.getString("gov", null) == null && cur.any { !it.endsWith(" performance") })
            prefs.edit().putString("gov", cur.joinToString("\n")).apply()
        Sh.run("for f in /sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_governor; do echo performance > \$f; done")
        return if (govLines().all { it.endsWith(" performance") }) "CPU: modo desempenho ativo."
        else "CPU: o sistema bloqueou a mudança."
    }

    private fun cpuOff() {
        if (Sh.rootOk != true) return
        prefs.getString("gov", null)?.lines()?.forEach { l ->
            val p = l.split(" ")
            if (p.size == 2) Sh.run("echo ${p[1]} > ${p[0]}")
        }
        prefs.edit().remove("gov").apply()
    }

    private fun apply() = task {
        if (!blocks && !leve && !perf && !noAnim && !ram && !cpu) return@task "Ative ao menos uma opção."
        val sb = StringBuilder()
        val s = if (leve) scale() else 1.0
        val ang = if (blocks) 1 else 0

        if (blocks || leve) {
            var r = Sh.run("cmd game set --mode performance --downscale %.2f --angle %d %s".format(Locale.US, s, ang, pkg))
            if (looksFailed(r)) { // Android recusou a combinação: aplica separado
                sb.appendLine("Combinação recusada, aplicando separado…")
                r = Sh.run("cmd game set --mode performance --downscale %.2f %s".format(Locale.US, s, pkg))
                if (looksFailed(r)) sb.appendLine(r)
            } else if (r.isNotEmpty()) sb.appendLine(r)
            Sh.run("cmd game mode performance $pkg")
            // Segunda via: configuração do jogo direto no sistema (funciona em aparelhos que ignoram o comando acima)
            val ua = if (blocks) ",useAngle=true" else ""
            Sh.run("cmd device_config put game_overlay $pkg \"mode=2,downscaleFactor=%.2f%s:mode=3,downscaleFactor=%.2f%s\"".format(Locale.US, s, ua, s, ua))
        }

        if (blocks) {
            Sh.run("settings put global angle_gl_driver_selection_pkgs $pkg")
            Sh.run("settings put global angle_gl_driver_selection_values angle")
            Sh.run("setprop $F '${features()}'")
        } else {
            Sh.run("setprop $F ''")
        }

        // Resolução da tela inteira (garante o efeito mesmo quando o modo de jogo é ignorado)
        if (leve && forceWm) {
            val sz = physSize()
            if (sz != null) {
                val k = maxOf(s, 0.5)
                val nw = ((sz.first * k).toInt() / 2) * 2
                val nh = ((sz.second * k).toInt() / 2) * 2
                Sh.run("wm size ${nw}x${nh}")
                sb.appendLine("Tela: ${nw}x${nh} (original ${sz.first}x${sz.second})")
            } else sb.appendLine("Não consegui ler o tamanho da tela.")
        } else {
            Sh.run("wm size reset")
        }

        if (noAnim) listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")
            .forEach { Sh.run("settings put global $it 0") }
        if (perf) {
            Sh.run("settings put global low_power 0")
            Sh.run("cmd power set-fixed-performance-mode-enabled true")
        }
        if (cpu) sb.appendLine(cpuOn()) else cpuOff()
        if (ram) {
            Sh.run("am kill-all")
            if (Sh.rootOk == true) Sh.run("sync; echo 3 > /proc/sys/vm/drop_caches")
        }

        Sh.run("am force-stop $pkg")
        Sh.run("monkey -p $pkg -c android.intent.category.LAUNCHER 1")
        sb.appendLine("Aplicado: ${if (blocks) features().ifEmpty { "ANGLE" } else "sem blocos"}, resolução %d%%".format((s * 100).toInt()))
        sb.toString().trim()
    }

    private fun show() = task {
        val cfg = Sh.run("cmd game list-configs $pkg")
        val prop = Sh.run("getprop $F")
        val ang = Sh.run("dumpsys gpu | grep -i -E 'angle|$pkg' | head -n 12")
        val wm = Sh.run("wm size")
        "$cfg\n\n$wm\n\n$F = $prop\n\n$ang".trim()
    }

    private fun restore() = task {
        Sh.run("cmd game reset $pkg")
        Sh.run("cmd device_config delete game_overlay $pkg")
        Sh.run("wm size reset")
        listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")
            .forEach { Sh.run("settings put global $it 1") }
        Sh.run("cmd power set-fixed-performance-mode-enabled false")
        cpuOff()
        Sh.run("setprop $F ''")
        Sh.run("settings delete global angle_gl_driver_selection_pkgs")
        Sh.run("settings delete global angle_gl_driver_selection_values")
        Sh.run("am force-stop $pkg")
        "Padrão restaurado. Reabra o jogo."
    }
}
