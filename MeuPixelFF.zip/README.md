# Meu Pixel FF

App que aplica, via Shizuku (ou root), o modo de jogo do Android com downscale de resolução
e driver ANGLE para o Free Fire. Não injeta nada no jogo.

## Compilar no GitHub (sem PC)
1. Crie um repositório no GitHub e envie todos os arquivos desta pasta (inclusive `.github`).
2. Aba **Actions** > **Build APK** > **Run workflow** (ou o push já dispara).
3. Quando terminar, abra a execução e baixe o artefato **MeuPixelFF-apk** (zip com o .apk).
4. Instale o APK, abra o Shizuku, autorize o app e toque em Aplicar.

## Comandos usados
- cmd game set --mode performance --downscale X --angle 1 PACOTE
- settings put global angle_gl_driver_selection_pkgs / _values
- am force-stop e monkey (reabrir)
- Restaurar: cmd game reset + settings delete

Requer Android 13+ (cmd game --downscale/--angle). Downscale aceito: 0.30 a 1.00.
