package com.meuff.pixel

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import rikka.shizuku.Shizuku
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val BG = Color.parseColor("#100B1E")
    private val PANEL = Color.parseColor("#21122F")
    private val LINE = Color.parseColor("#49305F")
    private val VIOLET = Color.parseColor("#B589FF")
    private val YELLOW = Color.parseColor("#FFE06A")
    private val MUTED = Color.parseColor("#C4ADC9")

    private val games = listOf("Free Fire" to "com.dts.freefireth", "Free Fire MAX" to "com.dts.freefiremax")
    // Estilo = nível de LOD de textura do ANGLE (0 = original, 1..4 = mais blocos)
    private val presets = listOf("Natural", "Brisa", "Arcade", "Voxel", "Máximo")

    private var pkg = games[0].second
    private var blocks = true   // Textura em blocos (ANGLE)
    private var leve = true     // Modo Leve (reduz resolução)
    private var level = 3        // 0..4
    private var sharp = true     // Pixels definidos (filtro nearest)
    private var steps = true     // Distância em etapas (mip nearest)

    private lateinit var status: TextView
    private lateinit var scaleLabel: TextView
    private lateinit var log: TextView
    private lateinit var seek: SeekBar        // resolução (Modo Leve)
    private lateinit var lvSeek: SeekBar      // intensidade dos blocos 0..4
    private lateinit var lvLabel: TextView
    private val presetBtns = mutableListOf<TextView>()
    private val gameBtns = mutableListOf<TextView>()

    private val onBinder = Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }
    private val onDead = Shizuku.OnBinderDeadListener { runOnUiThread { refresh() } }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun scale() = 0.30 + seek.progress / 100.0
    private val F = "debug.angle.feature_overrides_enabled"

    private fun box(fill: Int, stroke: Int, r: Int = 14) = GradientDrawable().apply {
        setColor(fill); setStroke(dp(1), stroke); cornerRadius = dp(r).toFloat()
    }

    private fun tv(t: String, size: Float = 14f, color: Int = Color.WHITE) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
    }

    private fun card(vararg v: android.view.View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = box(PANEL, LINE)
        setPadding(dp(16), dp(14), dp(16), dp(14))
        v.forEach { addView(it) }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
    }

    private fun toggleRow(title: String, sub: String, init: Boolean, on: (Boolean) -> Unit): LinearLayout {
        val txt = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv(title, 16f)); addView(tv(sub, 12f, MUTED))
        }
        val sw = Switch(this).apply { isChecked = init; setOnCheckedChangeListener { _, c -> on(c) } }
        return LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(txt, LinearLayout.LayoutParams(0, -2, 1f))
            addView(sw)
        }
    }

    private fun pill(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        setPadding(dp(4), dp(14), dp(4), dp(14))
        setOnClickListener { onClick() }
    }

    private fun bigBtn(t: String, primary: Boolean, f: () -> Unit) = TextView(this).apply {
        text = t; textSize = 15f; gravity = Gravity.CENTER
        setTextColor(if (primary) Color.parseColor("#1A1320") else Color.WHITE)
        background = if (primary) box(YELLOW, YELLOW, 16) else box(Color.TRANSPARENT, LINE, 16)
        setPadding(dp(8), dp(16), dp(8), dp(16))
        setOnClickListener { f() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(28))
            setBackgroundColor(BG)
        }
        root.addView(tv("Meu Pixel FF", 26f))
        status = tv("", 13f, MUTED); root.addView(status)
        root.addView(bigBtn("Conectar (root ou Shizuku)", false) { connect() })

        // Jogo
        val gRow = LinearLayout(this)
        games.forEachIndexed { i, (n, p) ->
            val b = pill(n) { pkg = p; paintGames() }
            gameBtns.add(b)
            gRow.addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { if (i > 0) leftMargin = dp(8) })
        }
        root.addView(card(tv("JOGO", 11f, VIOLET), gRow))

        // Textura em blocos
        val pRow = LinearLayout(this)
        presets.forEachIndexed { i, n ->
            val b = pill(n) { level = i; lvSeek.progress = i; paintPresets(); upLabel() }
            presetBtns.add(b)
            pRow.addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { if (i > 0) leftMargin = dp(6) })
        }
        lvLabel = tv("", 14f)
        lvSeek = SeekBar(this).apply {
            max = 4; progress = level
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { level = p; paintPresets(); upLabel() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        val ends = LinearLayout(this).apply {
            addView(tv("Mais detalhe", 11f, MUTED), LinearLayout.LayoutParams(0, -2, 1f))
            addView(tv("Mais blocos", 11f, MUTED))
        }
        root.addView(card(
            toggleRow("Textura em blocos", "Muda a amostragem de texturas (ANGLE).", true) { blocks = it },
            tv("ENCONTRE O SEU ESTILO", 11f, VIOLET).apply { setPadding(0, dp(14), 0, dp(6)) },
            pRow, lvLabel, lvSeek, ends,
            toggleRow("Pixels definidos", "Bordas marcadas, visual pixelado.", true) { sharp = it }
                .apply { setPadding(0, dp(14), 0, 0) },
            toggleRow("Distância em etapas", "Detalhe muda em degraus ao olhar longe.", true) { steps = it }
                .apply { setPadding(0, dp(14), 0, 0) }
        ))

        // Modo Leve
        scaleLabel = tv("", 14f)
        seek = SeekBar(this).apply {
            max = 70; progress = 40 // 0.70
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { upLabel() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(card(
            toggleRow("Modo Leve", "Reduz a resolução de renderização.", true) { leve = it },
            scaleLabel, seek
        ))

        root.addView(tv("Depois de aplicar, o jogo é reaberto. O ANGLE pode afetar outros apps; use Restaurar para voltar ao padrão.", 12f, MUTED).apply { setPadding(0, dp(14), 0, 0) })
        root.addView(bigBtn("Aplicar perfil e reabrir jogo", true) { apply() })
        root.addView(bigBtn("Ver configuração / ANGLE", false) { show() })
        root.addView(bigBtn("Restaurar padrão", false) { restore() })
        log = tv("", 12f, MUTED).apply { setPadding(0, dp(14), 0, 0) }
        root.addView(log)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG); layoutParams = ViewGroup.LayoutParams(-1, -1); addView(root)
        })
        paintGames(); paintPresets(); upLabel()
        thread { Sh.rootReady(); runOnUiThread { refresh() } }
        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPerm)
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeBinderReceivedListener(onBinder)
        Shizuku.removeBinderDeadListener(onDead)
        Shizuku.removeRequestPermissionResultListener(onPerm)
    }

    private fun paintGames() = gameBtns.forEachIndexed { i, b ->
        b.background = if (games[i].second == pkg) box(Color.parseColor("#352045"), YELLOW) else box(BG, LINE)
    }

    private fun paintPresets() = presetBtns.forEachIndexed { i, b ->
        b.background = if (i == level) box(Color.parseColor("#352045"), YELLOW) else box(BG, LINE)
    }

    private fun upLabel() {
        scaleLabel.text = "Resolução: %d%%".format((scale() * 100).toInt())
        lvLabel.text = "Intensidade dos blocos: %02d / 04".format(level)
    }

    private fun refresh() {
        status.text = when {
            Sh.rootOk == true -> "Acesso conectado: root"
            Sh.shizukuReady() -> "Acesso conectado: Shizuku"
            Sh.shizukuRunning() -> "Shizuku ativo, falta autorizar o app"
            else -> "Sem acesso. Toque em Conectar (root ou Shizuku)."
        }
    }

    private fun connect() {
        thread {
            val root = Sh.rootReady(true)
            runOnUiThread {
                if (!root) try {
                    if (Sh.shizukuRunning() && !Sh.shizukuReady()) Shizuku.requestPermission(1)
                } catch (_: Throwable) {}
                refresh()
            }
            val w = Sh.who()
            runOnUiThread { refresh(); out(if (w.isEmpty()) "Sem acesso. Conceda root ou inicie o Shizuku." else "Acesso OK: $w") }
        }
    }

    private fun out(s: String) { log.text = s }

    private fun task(f: () -> String) = thread {
        val r = try { f() } catch (e: Throwable) { "Erro: ${e.message}" }
        runOnUiThread { out(r) }
    }

    private fun looksFailed(s: String) = Regex("(?i)error|exception|unknown|usage|invalid|denied").containsMatchIn(s)

    private fun features(): String {
        val l = mutableListOf<String>()
        if (level > 0) l.add("forceTextureLodOffset$level")
        if (sharp) l.add("forceNearestFiltering")
        if (steps) l.add("forceNearestMipFiltering")
        return l.joinToString(":")
    }

    private fun apply() = task {
        if (!blocks && !leve) return@task "Ative Textura em blocos e/ou Modo Leve."
        val sb = StringBuilder()
        val s = if (leve) scale() else 1.0
        val ang = if (blocks) 1 else 0
        var r = Sh.run("cmd game set --mode performance --downscale %.2f --angle %d %s".format(Locale.US, s, ang, pkg))
        if (looksFailed(r)) { // Android recusou a combinação: aplica separado
            sb.appendLine("Combinação recusada, aplicando separado…")
            r = Sh.run("cmd game set --mode performance --downscale %.2f %s".format(Locale.US, s, pkg))
            if (looksFailed(r)) sb.appendLine(r)
        } else if (r.isNotEmpty()) sb.appendLine(r)
        Sh.run("cmd game mode performance $pkg")
        if (blocks) {
            Sh.run("settings put global angle_gl_driver_selection_pkgs $pkg")
            Sh.run("settings put global angle_gl_driver_selection_values angle")
            Sh.run("setprop $F '${features()}'")
        } else {
            Sh.run("setprop $F ''")
        }
        Sh.run("am force-stop $pkg")
        Sh.run("monkey -p $pkg -c android.intent.category.LAUNCHER 1")
        sb.appendLine("Aplicado: ${if (blocks) features().ifEmpty { "ANGLE" } else "sem blocos"}, resolução %d%%".format((s * 100).toInt()))
        sb.toString().trim()
    }

    private fun show() = task {
        val cfg = Sh.run("cmd game list-configs $pkg")
        val prop = Sh.run("getprop $F")
        val ang = Sh.run("dumpsys gpu | grep -i -E 'angle|$pkg' | head -n 12")
        "$cfg\n\n$F = $prop\n\n$ang".trim()
    }

    private fun restore() = task {
        Sh.run("cmd game reset $pkg")
        Sh.run("setprop $F ''")
        Sh.run("settings delete global angle_gl_driver_selection_pkgs")
        Sh.run("settings delete global angle_gl_driver_selection_values")
        Sh.run("am force-stop $pkg")
        "Padrão restaurado. Reabra o jogo."
    }
}
