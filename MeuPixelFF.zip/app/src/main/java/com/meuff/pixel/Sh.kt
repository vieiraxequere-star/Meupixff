package com.meuff.pixel

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/** Executa comandos de shell. Prefere root (su); se não houver, usa Shizuku (shell). */
object Sh {
    @Volatile var rootOk: Boolean? = null
        private set

    /** Testa root (pode abrir o pedido do Magisk/KernelSU). Chame fora da thread principal. */
    fun rootReady(force: Boolean = false): Boolean {
        if (!force) rootOk?.let { return it }
        val ok = try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id -u"))
            val o = p.inputStream.bufferedReader().readText().trim()
            p.waitFor()
            o == "0"
        } catch (e: Throwable) { false }
        rootOk = ok
        return ok
    }

    fun shizukuReady(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun shizukuRunning(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    private fun shizukuProcess(cmd: String): Process {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        return m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
    }

    fun run(cmd: String): String {
        val full = "$cmd 2>&1"
        val p = when {
            rootReady() -> Runtime.getRuntime().exec(arrayOf("su", "-c", full))
            shizukuReady() -> shizukuProcess(full)
            else -> throw IllegalStateException("Sem root nem Shizuku. Toque em Conectar.")
        }
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        return out.trim()
    }

    fun who(): String = try {
        when (val o = run("id -u")) { "0" -> "root"; "2000" -> "Shizuku (shell)"; else -> "uid $o" }
    } catch (e: Throwable) { "" }
}
